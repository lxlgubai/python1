import urllib.request
import re
import csv

class DBDY:
    def __init__(self): #初始化
        self.headers={"User-Agent":"Mozilla/5.0"}
        self.baseurl="https://movie.douban.com/subject/34795100/comments?"
    def readPage(self,url): #发送请求获取响应
        req=urllib.request.Request(url,headers=self.headers)
        res=urllib.request.urlopen(req)
        html=res.read().decode("utf-8")
        # print(html)
        self.parsePage(html)
    def parsePage(self,html): #爬取数据
        zzc=re.compile('<div class="comment">.*?<span class="comment-info">.*?class="">(.*?)</a>.*?<span class="comment-time " title="(.*?)">.*?</span>.*?class="short">(.*?)</span>',re.S)
        re_list=zzc.findall(html)
        # print(re_list)
        self.witePage(re_list)
    def witePage(self,re_list): #数据保存
        for gqzzc in re_list:
            with open("DBDY.csv","a",newline="",encoding="utf-8") as z:
                writer=csv.writer(z)
                Z=[gqzzc[0],gqzzc[1],gqzzc[2]]
                writer.writerow(Z)
    def workOn(self): #主函数
        begin=int(input("输入开始页数："))
        end=int(input("输入结束页数："))
        for z in range(begin,end+1):
            zz=(z - 1) * 20
            url=self.baseurl+"start="+str(zz)
            self.readPage(url)

if __name__=="__main__":
    zzc=DBDY()
    zzc.workOn()